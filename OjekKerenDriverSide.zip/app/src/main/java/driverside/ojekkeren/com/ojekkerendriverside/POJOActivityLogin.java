package driverside.ojekkeren.com.ojekkerendriverside;

/**
 * Created by andi on 4/29/2016.
 */
public class POJOActivityLogin {
    String response;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
