package driverside.ojekkeren.com.ojekkerendriverside;

/**
 * Created by andi on 4/30/2016.
 */
public class POJOFoodOrders {
    private String foodname;
    private String price;
    private String quantity;

    public String getFoodname() {
        return foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
