package driverside.ojekkeren.com.ojekkerendriverside;

/**
 * Created by andi on 4/29/2016.
 */
public class POJOCheckConnection {
}
