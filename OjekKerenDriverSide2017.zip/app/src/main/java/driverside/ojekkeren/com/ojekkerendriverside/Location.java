package driverside.ojekkeren.com.ojekkerendriverside;

/**
 * Created by User Pc on 21/9/2016.
 */
public class Location {
    private double lat;
    private double lng;

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }
}
